public class ExecAdmin extends NormalTest{
}
